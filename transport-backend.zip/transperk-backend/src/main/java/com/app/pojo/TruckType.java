package com.app.pojo;

public enum TruckType {
	MINI407_2000KG,MEDIUM709_3800KG,LARGE1109_8320KG
}
