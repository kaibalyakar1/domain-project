package com.app.pojo;

public enum Role {
	CUSTOMER,VENDOR;
}
