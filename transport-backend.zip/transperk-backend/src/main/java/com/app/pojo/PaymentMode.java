package com.app.pojo;

public enum PaymentMode {
	CASH,CHEQUE,BANK_TRANSFER,UPI
}
